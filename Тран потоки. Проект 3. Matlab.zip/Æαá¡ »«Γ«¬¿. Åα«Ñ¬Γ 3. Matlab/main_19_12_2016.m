function [ ] = main_19_12_2016( )
clc
clear all
close all

 
 


 

load Forecast Forecast; 
 
% 4 ���-�� ����� �� from � to
% 2  from 
% 3 to








load edges edges; 
% 3 from 
% 4 ro 
% 5 Capacity
% 6 Length (ft)
% 7  Free Flow Time (min)
%  







% save Forecast Forecast; 
% save edges edges; 
S_N=0;
graph=zeros(length(edges(:,4)),9 );

%  graph
% 1  from 
% 2 to 
% 3 Capacity (veh/h)
% 4 Length (ft)
% 5 Free Flow Time (min)
% 6  ������� -  delta F
% 7 ������� -  sum ( delta F_k *y_k)
% 8 ������� -  t �� � ���� t_k
% 9 ������� -  sum ( t_k*y_k)



graph(:,1:5 ) =edges(:,3:7 );
 

%  
graph(:,8,1)=edges(:,7,1);

max_1=max (max(edges(:,3:4)));



 

% ������� ��� ������� ���������. 
 
 mat_t_k=zeros(max_1,max_1);
 n=length(graph(:,1));
 
 
epselon=Find_epselon( graph,Forecast  ) ;
yes_no=0;  
for itt=1:10000
graph(:,6)=zeros(size(graph(:,6)));

 itt
 
 for i=1:length(graph(:,1))
      mat_t_k(graph(i,1),graph(i,2))= graph(i,8) ;
     
     
     
 end
  
 



graph=Calc_Marsh (Forecast,mat_t_k,graph);
y_k = Calc_y_k( graph(:,6),epselon);
graph(:,8)=find_t_k_plus_one( y_k,graph);
graph(:,7 )= graph(:,7 ) + graph(:,6)*y_k;
S_N=S_N+y_k;

graph(:,9)=graph(:,9)+graph(:,8)*y_k;
 

if mod ( itt,100)==0

    yes_no= criteria_ostanova(graph,S_N,epselon);

    if yes_no==1
       break
    end
    
end
 
end



 
end











function [P,l_zvezda,P_1] = diijkstra_1(G,s,P_zvezda,l_zvezda)

n=length(G(1,:));
d=ones(1,n)*Inf;
d(s)=0;
P=zeros(n);
U=zeros(1,n);
flag=0;
flag_per=0;




arr=ones(1,n);
for i=2:n
   arr(i)=arr(i-1)+1;
end
 
G = setupgraph(G,inf,1);

min_d=min(d(U==0));
cur_vershina = min ( arr( d==min_d & U==0 ));
P(:,1)=ones(n,1)*cur_vershina;


  
 
while  min(U)~= 1
 flag=0;  
    
    min_d=min(d(U==0));
    
  cur_vershina = min ( arr( d==min_d & U==0 ));
 U(cur_vershina)=1;
   
    for i=1:n
        if G(cur_vershina,i)~=Inf
            
            if U(i)==1
                continue
            end
            
            
            
            
           
            
             

            
            
            
          
            if d(i)>d(cur_vershina)+G(cur_vershina,i)
                
                
                if     (size(l_zvezda ))>0
            
                    for  i_p_zvezda=1:length(l_zvezda(:))
                
                        if i==l_zvezda(i_p_zvezda)
                
                             for i_U=1:n
                    
                                if U(i_U)==0
                                        max_element = max (arr( P(cur_vershina,:)~=0));
                                        cusor_marsh=  P(cur_vershina,1:max_element);
 
                                        max_elem_P_zvezda=min(arr(P_zvezda(i_U,:)==0))-1;
                                        P_zvezda_cusor= P_zvezda(i_U,1:max_elem_P_zvezda);
              
                                        flag_per=0;
                   
               
                   
                                         for i_P_zvezda_cusor=1:max_elem_P_zvezda
                                             for i_cusor_marsh=1:max_element
                           
                                                 if P_zvezda_cusor(i_P_zvezda_cusor)==cusor_marsh(i_cusor_marsh)
                              
                               
                                                flag_per=1; 
                               
                                                 end
                      
                                             end
                                         end
                   
                                        if flag_per==0
                                            P(i_U,1: (max_element+max_elem_P_zvezda))=[cusor_marsh P_zvezda_cusor];
                                             U(i_U)=1;
                                        end
                   
                        
                        
                        
                    end
                    
                    
                end
  
             flag  =1;
            end
    
            end
            
            
           end
            
                
                
                
                
                if flag==0
                
                d(i)=d(cur_vershina)+G(cur_vershina,i);
                max_element= max (arr( P(cur_vershina,:)~=0));
                cusor_marsh=  P(cur_vershina,1:max_element);
                P(i,1: (max_element+1))=[cusor_marsh i];
                
                end
                
 
                 
                 
            end
            
        end
            
           
        
        
        
    end
    
 
  
end
 
 
 l_zvezda =[l_zvezda s];
 P_1=P;
 P=[P;
     P_zvezda];
 
 
 
end





function [graph] = Calc_Marsh(Forecast,mat_t_k,graph)

P_zvezda=[]; 
l_zvezda=[]; 
 
S=Find_S(Forecast);

    
   for i=1:length(S)
    from=S(i) ;

 
    [P_zvezda l_zvezda,P]=diijkstra_1(mat_t_k,from,P_zvezda,l_zvezda);
    
    graph= Update_graph(S(i),Forecast,P,graph );
   end
    
  
   
 
end



function graph  = Update_graph(S,Forecast,P,graph )

% cur_Forecast= Forecast(:,3)==S

cur_Forecast=Forecast(Forecast(:,3)==S,2:4);

for i=1:length(cur_Forecast(:,3))
    to=cur_Forecast(i,3);
    AverageDaylyVolume=cur_Forecast(i,1);
    path = P(to, P(to,:)~=0);
        for j=1:length(path)-1
            L_1=path(j);
            L_2=path(j+1);
            
            graph( graph(:,1)==L_1 & graph(:,2)==L_2 ,6) = graph( graph(:,1)==L_1 & graph(:,2)==L_2 ,6) -AverageDaylyVolume;
            
            
        end
     
     
    
    
end
 
end
 
 
 


function S = Find_S( Forecast )
S=[];
cur_s=0; 
for i=1: length(Forecast(:,1))
    from=Forecast(i,3);
    if cur_s~=from
        S=[S from];
        cur_s=from;
        
    end
    
    
     
end



end


function y_k = Calc_y_k( y,epselon)

% graph(:,6)
y_k=epselon/norm(y)/norm(y);


end




function t_k_plus_1=find_t_k_plus_one( y_k,graph)

t_k_plus_1= zeros(1,length(graph(:,1)));

n=length(graph(:,1));

 
for i= 1:n

% % 
t_vershina= graph(i,8 )- ( graph(i,3 )+graph(i,6) )*y_k;

if t_vershina>graph(i,5 )
t_k_plus_1(i)=t_vershina;
else
t_k_plus_1(i)=graph(i,5);
end

 






end


end


function epselon = Find_epselon( graph,Forecast )
max_1=max (max(graph(:,1:2)));


 
 
 mat_t_k=zeros(max_1,max_1);
 n=length(graph(:,4)); 
 
 for i=1:n 
      mat_t_k(graph(i,1),graph(i,2))= graph(i,8) ;
     
     
     
 end

 graph=Calc_Marsh (Forecast,mat_t_k,graph);
 
 Y_0= graph(:,5)'*graph(:,6)+0; 
 y_k = Calc_y_k( graph(:,6),0);
 
 X_0=find_X_0(y_k,graph);
 
 
 epselon= abs ( X_0+Y_0)/100;
 

end


function X_0 = find_X_0( y_k,graph  )
n= length(graph(:,1));
s=zeros(1,n);
 
 
for i=1:n

 if  graph(i,6)+ graph(i,3)<0
%      s=0
  
     s(i)=0;
 else 
%      s~=0

    s(i)= graph(i,6)+ graph(i,3);
 end
     



end

f_0=graph(i,3)-s;
 
X_0 =  f_0*graph(:,5);

end

function yes_no = criteria_ostanova( graph,S_N,epselon )
 

yes_no=0;
% find_Y
t_N=graph(:,9)/S_N;

Y_N=sum ( graph(:,6).*t_N + graph(:,3).*(t_N-graph(:,5) ) );

X_N=Find_X_N (graph,S_N);

% Y_N
% X_N
% abs (Y_N+X_N)

if  abs (Y_N+X_N)<epselon
    yes_no=1;
end
    




end

function X_N = Find_X_N( graph,S_N )


n= length(graph(:,1));
s=zeros(1,n);
 
 

% case 1  
 
for i=1:n
 
 if  graph(i,7)+ S_N*graph(i,3)<0
%      s=0
  
     s(i)=0;
     else 
%      s~=0
     s(i)= graph(i,7)+ S_N*graph(i,3);
 end
     



end

f_0=graph(i,3)-s;
 
X_N =  f_0*graph(:,5);




end
